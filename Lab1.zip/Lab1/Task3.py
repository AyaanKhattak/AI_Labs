def cube(n):
    return n**3


print("Cube of 3: ",cube(3))